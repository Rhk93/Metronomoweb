package it.ignazio.metronomo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int SCEGLI_FOTO = 1001;
    private static final int PERMESSO_MICROFONO = 2001;

    private WebView web;
    private ValueCallback<Uri[]> fotoCallback;

    // Comandi vocali (VIA / STOP)
    private SpeechRecognizer riconoscitore;
    private boolean voceAttiva = false;
    private final Handler mano = new Handler(Looper.getMainLooper());

    // Voce che conta: numeri registrati con la voce italiana del telefono
    private static final String[] NUMERI = {"uno", "due", "tre", "quattro", "cinque", "sei", "sette", "otto",
            "nove", "dieci", "undici", "dodici", "tredici", "quattordici", "quindici", "sedici", "e"};
    private TextToSpeech tts;
    private boolean ttsPronto = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Lo schermo resta acceso mentre si studia
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Voce(), "AndroidVoce");

        // Apre la galleria quando l'utente sceglie la foto di sfondo
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fotoCallback != null) {
                    fotoCallback.onReceiveValue(null);
                }
                fotoCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                try {
                    startActivityForResult(Intent.createChooser(intent, "Scegli una foto"), SCEGLI_FOTO);
                } catch (Exception e) {
                    fotoCallback = null;
                    return false;
                }
                return true;
            }
        });

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    /* ================== PONTE CON LA PAGINA ================== */
    private class Voce {
        @JavascriptInterface
        public void avvia() {
            mano.post(() -> {
                voceAttiva = true;
                if (Build.VERSION.SDK_INT >= 23
                        && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PERMESSO_MICROFONO);
                } else {
                    iniziaAscolto();
                }
            });
        }

        @JavascriptInterface
        public void preparaNumeri() {
            mano.post(() -> creaNumeri());
        }

        @JavascriptInterface
        public void ferma() {
            mano.post(() -> {
                voceAttiva = false;
                fermaAscolto();
            });
        }
    }

    private void inviaAllaPagina(String js) {
        if (web != null) web.evaluateJavascript(js, null);
    }

    /* ================== VOCE CHE CONTA ================== */
    private void creaNumeri() {
        if (tts != null) {
            if (ttsPronto) registraNumeri();
            return;
        }
        tts = new TextToSpeech(this, stato -> {
            if (stato == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.ITALIAN);
                tts.setSpeechRate(1.25f);
                ttsPronto = true;
                registraNumeri();
            }
        });
    }

    private void registraNumeri() {
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) {}
            @Override public void onError(String id) {}
            @Override public void onDone(String id) {
                try {
                    int i = Integer.parseInt(id);
                    File f = new File(getCacheDir(), "numero" + i + ".wav");
                    FileInputStream in = new FileInputStream(f);
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] pezzo = new byte[8192];
                    int n;
                    while ((n = in.read(pezzo)) > 0) out.write(pezzo, 0, n);
                    in.close();
                    final String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                    mano.post(() -> inviaAllaPagina("window.appNumero && appNumero(" + i + ",'" + b64 + "')"));
                } catch (Exception ignored) {}
            }
        });
        for (int i = 0; i < NUMERI.length; i++) {
            File f = new File(getCacheDir(), "numero" + i + ".wav");
            tts.synthesizeToFile(NUMERI[i], new Bundle(), f, String.valueOf(i));
        }
    }

    /* ================== RICONOSCIMENTO VOCALE ================== */
    private void iniziaAscolto() {
        if (!voceAttiva) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            voceAttiva = false;
            inviaAllaPagina("window.appVoceStato && appVoceStato('nonDisponibile')");
            return;
        }
        if (riconoscitore == null) {
            riconoscitore = SpeechRecognizer.createSpeechRecognizer(this);
            riconoscitore.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) {}
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float v) {}
                @Override public void onBufferReceived(byte[] b) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onEvent(int t, Bundle b) {}

                @Override public void onPartialResults(Bundle b) { leggi(b); }

                @Override public void onResults(Bundle b) {
                    leggi(b);
                    riprendi(150);
                }

                @Override public void onError(int errore) {
                    if (errore == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        voceAttiva = false;
                        inviaAllaPagina("window.appVoceStato && appVoceStato('permesso')");
                        return;
                    }
                    // Nessuna parola o silenzio: ricomincia ad ascoltare
                    riprendi(errore == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 600 : 250);
                }
            });
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500);
        try {
            riconoscitore.startListening(intent);
        } catch (Exception e) {
            riprendi(800);
        }
    }

    private void leggi(Bundle b) {
        ArrayList<String> frasi = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (frasi == null || frasi.isEmpty()) return;
        String testo = frasi.get(0).replace("\\", " ").replace("'", " ");
        inviaAllaPagina("window.appVoce && appVoce('" + testo + "')");
    }

    private void riprendi(long ritardo) {
        if (!voceAttiva) return;
        mano.postDelayed(() -> {
            if (voceAttiva && riconoscitore != null) {
                try { riconoscitore.cancel(); } catch (Exception ignored) {}
                iniziaAscolto();
            }
        }, ritardo);
    }

    private void fermaAscolto() {
        mano.removeCallbacksAndMessages(null);
        if (riconoscitore != null) {
            try { riconoscitore.cancel(); riconoscitore.destroy(); } catch (Exception ignored) {}
            riconoscitore = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMESSO_MICROFONO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                iniziaAscolto();
            } else {
                voceAttiva = false;
                inviaAllaPagina("window.appVoceStato && appVoceStato('permesso')");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SCEGLI_FOTO && fotoCallback != null) {
            Uri[] risultato = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fotoCallback.onReceiveValue(risultato);
            fotoCallback = null;
        }
    }

    @Override
    protected void onPause() {
        // Ferma il metronomo quando si esce dall'app (salvo diversa impostazione)
        if (web != null) {
            web.evaluateJavascript("window.appPausa && appPausa()", null);
        }
        fermaAscolto();   // libera il microfono; se era acceso riparte al ritorno
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Se l'ascolto era acceso, riprende
        if (voceAttiva && riconoscitore == null) iniziaAscolto();
    }

    @Override
    public void onBackPressed() {
        // Se è aperto il pannello impostazioni lo chiude, altrimenti esce
        web.evaluateJavascript("window.appIndietro ? appIndietro() : false", value -> {
            if (!"true".equals(value)) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        fermaAscolto();
        if (tts != null) tts.shutdown();
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
